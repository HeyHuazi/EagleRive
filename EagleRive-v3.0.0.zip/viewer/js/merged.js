// EagleRive Viewer - Merged Modules

// ===== utils.js =====

/**
 * Utility functions for Rive viewer
 */

const RiveUtils = {
    /**
     * Escape HTML attribute values
     */
    escapeAttr(s) {
        return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
    },

    /**
     * Convert Rive color number to hex string
     */
    riveColorToHex(c) {
        const n = (c < 0 ? c + 0x100000000 : c) >>> 0;
        const r = (n >> 16) & 0xFF;
        const g = (n >> 8) & 0xFF;
        const b = n & 0xFF;
        return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
    },

    /**
     * Convert hex string to Rive color number
     */
    hexToRiveColor(hex) {
        hex = hex.replace('#', '');
        const n = parseInt(hex, 16);
        return (0xFF000000 | n) >>> 0;
    }
};

// WASM DataType enum values
const DataType = {
    none: 0,
    string: 1,
    number: 2,
    boolean: 3,
    color: 4,
    list: 5,
    enumType: 6,
    trigger: 7,
    viewModel: 8
};

// High-level PropertyType string enum
const PropertyType = {
    number: 'number',
    string: 'string',
    boolean: 'boolean',
    color: 'color',
    trigger: 'trigger',
    enum: 'enum',
    list: 'list',
    image: 'image',
    artboard: 'artboard'
};

/**
 * Normalize property type to unified string category
 * Supports both WASM numeric enums and high-level API string enums
 */
function normalizeType(t) {
    if (typeof t === 'number') {
        switch (t) {
            case DataType.trigger: return 'trigger';
            case DataType.boolean: return 'boolean';
            case DataType.number: return 'number';
            case DataType.string: return 'string';
            case DataType.color: return 'color';
            case DataType.list: return 'list';
            case DataType.enumType: return 'enum';
            case DataType.viewModel: return 'viewModel';
            default: return 'unknown-' + t;
        }
    }
    if (typeof t === 'string') {
        const s = t.toLowerCase();
        if (s === 'enum' || s === 'enumtype') return 'enum';
        if (s === 'viewmodel') return 'viewModel';
        return s;
    }
    return 'unknown';
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    // Node.js environment
    module.exports = { RiveUtils, DataType, PropertyType, normalizeType };
} else {
    // Browser environment - expose to window
    window.RiveUtils = RiveUtils;
    window.DataType = DataType;
    window.PropertyType = PropertyType;
    window.normalizeType = normalizeType;
}


// ===== animation.js =====

/**
 * Animation module for Rive
 */

const Animation = (function() {
    let currentAnim = null;

    /**
     * Populate animation list
     */
    function populateAnimations(riveInstance) {
        const anims = riveInstance.animationNames || [];
        const list = document.getElementById('animList');

        if (!anims.length) {
            list.innerHTML = '<div class="empty">暂无动画</div>';
            return;
        }

        currentAnim = anims[0];
        list.innerHTML = anims.map((a, i) =>
            '<div class="item' + (i === 0 ? ' active' : '') + '" data-anim="' + a + '">' + a + '</div>'
        ).join('');

        list.querySelectorAll('.item').forEach(function(el) {
            el.addEventListener('click', function() {
                list.querySelectorAll('.item').forEach(function(x) { x.classList.remove('active'); });
                el.classList.add('active');

                // Stop current state machine if running
                var curSM = window.stateMachineModule ? window.stateMachineModule.getCurrentSM() : null;
                if (curSM) {
                    try { riveInstance.stop(curSM); } catch (e) {}
                }

                // Stop current animation
                if (currentAnim) {
                    try { riveInstance.stop(currentAnim); } catch (e) {}
                }

                currentAnim = el.dataset.anim;
                riveInstance.play(currentAnim);
            });
        });
    }

    function playAnim(riveInstance, name) {
        if (name) {
            riveInstance.play(name);
        }
    }

    return {
        populateAnimations,
        playAnim,
        getCurrentAnim: () => currentAnim,
        setCurrentAnim: (anim) => { currentAnim = anim; }
    };
})();

// Expose to global window object
window.Animation = Animation;


// ===== state-machine.js =====

/**
 * State Machine module for Rive
 */

const StateMachine = (function() {
    let currentSM = null;
    let inputs = [];

    /**
     * Populate state machine dropdown
     */
    function populateStateMachines(riveInstance) {
        const sms = riveInstance.stateMachineNames || [];
        const smSection = document.getElementById('smSection');
        const sel = document.getElementById('smSelect');

        document.getElementById('smSection').style.display = sms.length ? '' : 'none';

        sel.innerHTML = sms.length
            ? sms.map(s => '<option value="' + s + '">' + s + '</option>').join('')
            : '<option value="">暂无状态机</option>';

        sel.onchange = () => {
            if (sel.value) {
                playSM(riveInstance, sel.value);
                requestAnimationFrame(() => requestAnimationFrame(() => loadSMInputs(riveInstance, sel.value)));
            }
        };

        if (sms.length) {
            playSM(riveInstance, sms[0]);
            requestAnimationFrame(() => requestAnimationFrame(() => loadSMInputs(riveInstance, sms[0])));
        }
    }

    /**
     * Play a state machine
     */
    function playSM(riveInstance, name) {
        const { playAnim, getCurrentAnim } = window.Animation || {};

        // Stop current animation if any
        const curAnim = getCurrentAnim ? getCurrentAnim() : null;
        if (curAnim) {
            try { riveInstance.stop(curAnim); } catch (e) {}
        }

        // Stop previous SM if different
        if (currentSM && currentSM !== name) {
            try { riveInstance.stop(currentSM); } catch (e) {}
        }

        currentSM = name;
        riveInstance.play(name);
    }

    /**
     * Load state machine inputs
     */
    function loadSMInputs(riveInstance, name) {
        const box = document.getElementById('smInputs');
        box.style.display = 'none';
        box.innerHTML = '';
        inputs = [];

        try {
            const smInputs = riveInstance.stateMachineInputs(name);
            if (!smInputs || smInputs.length === 0) return;

            inputs = smInputs;
            const triggers = [];
            const bools = [];
            const nums = [];

            for (let i = 0; i < inputs.length; i++) {
                const inp = inputs[i];
                const type = inp.type;

                if (type === rive.StateMachineInputType.Trigger) {
                    triggers.push(inp);
                } else if (type === rive.StateMachineInputType.Boolean) {
                    bools.push(inp);
                } else if (type === rive.StateMachineInputType.Number) {
                    nums.push(inp);
                }
            }

            let html = '';

            if (triggers.length) {
                html += '<div class="sm-type-group"><div class="sm-type-hd">触发器 <span class="sm-type-badge">' +
                        triggers.length + '</span></div><div class="trigger-grid">';
                triggers.forEach(function(t) {
                    html += '<button class="trigger-btn" data-trigger="' + RiveUtils.escapeAttr(t.name) + '">' +
                            RiveUtils.escapeAttr(t.name) + '</button>';
                });
                html += '</div></div>';
            }

            if (bools.length) {
                html += '<div class="sm-type-group"><div class="sm-type-hd">布尔值 <span class="sm-type-badge">' +
                        bools.length + '</span></div>';
                bools.forEach(function(b) {
                    html += '<div class="icard"><div class="sw-row"><span class="icard-label" style="margin:0">' +
                            RiveUtils.escapeAttr(b.name) +
                            '</span><label class="sw"><input type="checkbox" data-bool="' +
                            RiveUtils.escapeAttr(b.name) + '"' + (b.value ? ' checked' : '') +
                            '><span class="sw-track"></span></label></div></div>';
                });
                html += '</div>';
            }

            if (nums.length) {
                html += '<div class="sm-type-group"><div class="sm-type-hd">数值 <span class="sm-type-badge">' +
                        nums.length + '</span></div>';
                nums.forEach(function(n) {
                    html += '<div class="icard"><label class="icard-label">' + RiveUtils.escapeAttr(n.name) +
                            '</label><input type="number" class="ninput" data-num="' +
                            RiveUtils.escapeAttr(n.name) + '" value="' + n.value + '" step="any"></div>';
                });
                html += '</div>';
            }

            if (html) {
                box.innerHTML = html;
                box.style.display = '';
                bindSMEvents(riveInstance);
            }
        } catch (e) {
            console.warn('[Rive] Failed to load SM inputs:', e);
        }
    }

    /**
     * Bind state machine input events
     */
    function bindSMEvents(riveInstance) {
        const box = document.getElementById('smInputs');

        // Triggers
        box.querySelectorAll('[data-trigger]').forEach(function(el) {
            el.addEventListener('click', function() {
                const inp = inputs.find(i => i.name === this.dataset.trigger);
                if (inp) {
                    inp.fire();
                    console.log('[Rive] SM trigger fired:', this.dataset.trigger);
                } else {
                    console.warn('[Rive] SM trigger not found:', this.dataset.trigger);
                }
            });
        });

        // Booleans
        box.querySelectorAll('[data-bool]').forEach(function(el) {
            el.addEventListener('change', function() {
                const inp = inputs.find(i => i.name === this.dataset.bool);
                if (inp) {
                    inp.value = this.checked;
                    console.log('[Rive] SM bool set:', this.dataset.bool, '=', this.checked);
                } else {
                    console.warn('[Rive] SM bool not found:', this.dataset.bool);
                }
            });
        });

        // Numbers
        box.querySelectorAll('[data-num]').forEach(function(el) {
            el.addEventListener('input', function() {
                const inp = inputs.find(i => i.name === this.dataset.num);
                if (inp) {
                    inp.value = parseFloat(this.value) || 0;
                    console.log('[Rive] SM num set:', this.dataset.num, '=', parseFloat(this.value) || 0);
                } else {
                    console.warn('[Rive] SM num not found:', this.dataset.num);
                }
            });
        });
    }

    return {
        populateStateMachines,
        playSM,
        loadSMInputs,
        getCurrentSM: () => currentSM,
        setCurrentSM: (sm) => { currentSM = sm; }
    };
})();

// Expose to global window object
window.StateMachine = StateMachine;


// ===== data-binding.js =====

/**
 * Data Binding module for Rive ViewModel
 */

const DataBinding = (function() {
    let currentVMI = null;

    /**
     * Get property descriptors with multiple fallback strategies
     */
    function getPropertyDescriptors(vmi, vmName) {
        let props = [];

        // Strategy 1: Direct from ViewModelInstance
        try { props = vmi.properties; } catch (e) { console.warn('[Rive] vmi.properties failed:', e); }
        if (props && props.length) {
            console.log('[Rive] 属性来源: vmi.properties, 数量:', props.length);
            return props;
        }

        // Strategy 2: From ViewModel object
        try {
            let vm = null;
            if (vmName) {
                try { vm = window.riveInstance.viewModelByName(vmName); } catch (e2) {}
            }
            if (!vm) {
                try { vm = window.riveInstance.defaultViewModel(); } catch (e2) {}
            }
            if (vm) {
                try { props = vm.properties; } catch (e2) {}
                if (props && props.length) {
                    console.log('[Rive] 属性来源: vm.properties, 数量:', props.length);
                    return props;
                }
            }
        } catch (e) { console.warn('[Rive] vm.properties failed:', e); }

        // Strategy 3: Try to get from runtime
        try {
            const rt = vmi._runtimeInstance || vmi.runtimeInstance || vmi.nativeInstance;
            if (rt && typeof rt.getProperties === 'function') {
                const raw = rt.getProperties();
                if (raw && raw.length) {
                    console.log('[Rive] 属性来源: runtime.getProperties(), 数量:', raw.length);
                    return Array.prototype.map.call(raw, function(p) {
                        return { name: p.name, type: p.type };
                    });
                }
            }
        } catch (e) { console.warn('[Rive] runtime.getProperties failed:', e); }

        return [];
    }

    /**
     * Populate ViewModel dropdown
     */
    function populateViewModel(riveInstance) {
        const sel = document.getElementById('vmSelect');
        const box = document.getElementById('vmProps');
        const vmSection = document.getElementById('vmSection');
        box.innerHTML = '';
        currentVMI = null;

        function hideVM() {
            vmSection.style.display = 'none';
        }

        if (!riveInstance) {
            sel.innerHTML = '<option value="">无视图模型</option>';
            hideVM();
            return;
        }

        let count = 0;
        try { count = riveInstance.viewModelCount || 0; } catch (e) {
            console.warn('[Rive] viewModelCount error:', e);
        }
        console.log('[Rive] viewModelCount:', count);

        // Check autoBind default instance
        let autoVMI = null;
        try { autoVMI = riveInstance.viewModelInstance; } catch (e) {}
        console.log('[Rive] autoBind viewModelInstance:', autoVMI ? '已绑定' : '未绑定');

        if (!count && !autoVMI) {
            sel.innerHTML = '<option value="">无视图模型</option>';
            hideVM();
            return;
        }

        vmSection.style.display = '';

        // Get ViewModel name list
        const vmInfos = [];
        for (let i = 0; i < count; i++) {
            try {
                const vm = riveInstance.viewModelByIndex(i);
                const name = vm && vm.name ? vm.name : '视图模型 ' + i;
                console.log('[Rive] viewModelByIndex(' + i + '):', name, vm ? '有效' : '无效');
                vmInfos.push({ name: name, index: i });
            } catch (e) {
                console.warn('[Rive] viewModelByIndex(' + i + ') error:', e);
                vmInfos.push({ name: '视图模型 ' + i, index: i });
            }
        }

        // If count=0 but has autoVMI, use defaultViewModel to get name
        if (!vmInfos.length && autoVMI) {
            let defName = '默认视图模型';
            try {
                const defVM = riveInstance.defaultViewModel();
                if (defVM && defVM.name) defName = defVM.name;
            } catch (e) {}
            vmInfos.push({ name: defName, index: -1 });
        }

        sel.innerHTML = vmInfos.map(function(info) {
            return '<option value="' + RiveUtils.escapeAttr(info.name) + '" data-idx="' + info.index + '">' +
                   RiveUtils.escapeAttr(info.name) + '</option>';
        }).join('');

        sel.onchange = function() {
            if (sel.value) loadVMProperties(riveInstance, sel.value);
        };

        if (vmInfos.length) loadVMProperties(riveInstance, vmInfos[0].name);
    }

    /**
     * Load ViewModel properties
     */
    function loadVMProperties(riveInstance, vmName) {
        const box = document.getElementById('vmProps');
        box.innerHTML = '';
        currentVMI = null;

        try {
            let vmi = null;

            // Strategy 1: Use autoBind default instance
            try { vmi = riveInstance.viewModelInstance; } catch (e) {
                console.warn('[Rive] R.viewModelInstance error:', e);
            }

            // Strategy 2: Get by name → defaultInstance → bind
            if (!vmi) {
                console.log('[Rive] autoBind 未获取到实例，尝试手动实例化');
                let vm = null;
                try { vm = riveInstance.viewModelByName(vmName); } catch (e) {}
                if (!vm) { try { vm = riveInstance.defaultViewModel(); } catch (e) {} }
                if (vm) {
                    console.log('[Rive] 获取到 ViewModel:', vm.name || vmName);
                    let inst = null;
                    try { inst = vm.defaultInstance(); } catch (e) {
                        console.warn('[Rive] vm.defaultInstance() failed:', e);
                    }
                    if (!inst) {
                        try { inst = vm.instance(); } catch (e) {
                            console.warn('[Rive] vm.instance() failed:', e);
                        }
                    }
                    if (inst) {
                        try { riveInstance.bindViewModelInstance(inst); } catch (e) {
                            console.warn('[Rive] bindViewModelInstance failed:', e);
                        }
                        vmi = inst;
                    }
                }
            }

            console.log('[Rive] loadVMProperties:', vmName, '| vmi:', vmi ? '有实例' : '无实例');

            if (!vmi) {
                box.innerHTML = '<div class="empty">无法加载视图模型实例</div>';
                return;
            }

            currentVMI = vmi;
            renderVMProperties(vmi, vmName, box, 0);
        } catch (e) {
            console.error('[Rive] loadVMProperties error:', e);
            box.innerHTML = '<div class="empty">错误：' + RiveUtils.escapeAttr(e.message || e) + '</div>';
        }
    }

    /**
     * Render ViewModel properties (supports nested ViewModels)
     */
    function renderVMProperties(vmi, vmName, container, depth) {
        const propDescs = getPropertyDescriptors(vmi, depth === 0 ? vmName : null);
        console.log('[Rive] renderVMProperties:', vmName, '| depth:', depth, '| props:', propDescs.length);

        if (!propDescs.length) {
            container.innerHTML += '<div class="empty">暂无属性</div>';
            return;
        }

        // Group by type
        const groups = {
            triggers: [], bools: [], nums: [], strs: [],
            colors: [], enums: [], lists: [], viewModels: []
        };

        for (let idx = 0; idx < propDescs.length; idx++) {
            const pd = propDescs[idx];
            const pname = pd.name;
            const ptype = normalizeType(pd.type);

            switch (ptype) {
                case 'trigger':
                    try {
                        const t = vmi.trigger(pname);
                        if (t) groups.triggers.push({ name: pname, acc: t });
                    } catch (e) { console.warn('[Rive] trigger accessor failed:', pname, e); }
                    break;
                case 'boolean':
                    try {
                        const b = vmi.boolean(pname);
                        if (b) groups.bools.push({ name: pname, acc: b });
                    } catch (e) { console.warn('[Rive] boolean accessor failed:', pname, e); }
                    break;
                case 'number':
                    try {
                        const n = vmi.number(pname);
                        if (n) groups.nums.push({ name: pname, acc: n });
                    } catch (e) { console.warn('[Rive] number accessor failed:', pname, e); }
                    break;
                case 'string':
                    try {
                        const s = vmi.string(pname);
                        if (s) groups.strs.push({ name: pname, acc: s });
                    } catch (e) { console.warn('[Rive] string accessor failed:', pname, e); }
                    break;
                case 'color':
                    try {
                        const c = vmi.color(pname);
                        if (c) groups.colors.push({ name: pname, acc: c });
                    } catch (e) { console.warn('[Rive] color accessor failed:', pname, e); }
                    break;
                case 'enum':
                    try {
                        const en = vmi.enum(pname);
                        if (en) groups.enums.push({ name: pname, acc: en });
                    } catch (e) { console.warn('[Rive] enum accessor failed:', pname, e); }
                    break;
                case 'list':
                    try {
                        const l = vmi.list(pname);
                        if (l) groups.lists.push({ name: pname, acc: l });
                    } catch (e) { console.warn('[Rive] list accessor failed:', pname, e); }
                    break;
                case 'viewModel':
                    try {
                        const vmChild = vmi.viewModel(pname);
                        if (vmChild) groups.viewModels.push({ name: pname, acc: vmChild });
                    } catch (e) { console.warn('[Rive] viewModel accessor failed:', pname, e); }
                    break;
                default:
                    console.warn('[Rive] 未知属性类型:', pname, 'type=', pd.type, 'normalized=', ptype);
                    break;
            }
        }

        let html = '';
        const prefix = depth > 0 ? 'd' + depth + '-' : '';

        // Render triggers
        if (groups.triggers.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">触发器 <span class="sm-type-badge">' +
                    groups.triggers.length + '</span></div><div class="trigger-grid">';
            groups.triggers.forEach(function(t) {
                html += '<button class="trigger-btn" data-vm-trg="' + RiveUtils.escapeAttr(t.name) + '">' +
                        RiveUtils.escapeAttr(t.name) + '</button>';
            });
            html += '</div></div>';
        }

        // Render booleans
        if (groups.bools.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">布尔值 <span class="sm-type-badge">' +
                    groups.bools.length + '</span></div>';
            groups.bools.forEach(function(b) {
                let val = false;
                try { val = b.acc.value; } catch (e) {}
                html += '<div class="icard"><div class="sw-row"><span class="icard-label" style="margin:0">' +
                        RiveUtils.escapeAttr(b.name) +
                        '</span><label class="sw"><input type="checkbox" data-vm-bool="' +
                        RiveUtils.escapeAttr(b.name) + '"' + (val ? ' checked' : '') +
                        '><span class="sw-track"></span></label></div></div>';
            });
            html += '</div>';
        }

        // Render numbers
        if (groups.nums.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">数值 <span class="sm-type-badge">' +
                    groups.nums.length + '</span></div>';
            groups.nums.forEach(function(n) {
                let val = 0;
                try { val = n.acc.value; } catch (e) {}
                html += '<div class="icard"><label class="icard-label">' + RiveUtils.escapeAttr(n.name) +
                        '</label><input type="number" class="ninput" data-vm-num="' +
                        RiveUtils.escapeAttr(n.name) + '" value="' + val + '" step="any"></div>';
            });
            html += '</div>';
        }

        // Render strings
        if (groups.strs.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">字符串 <span class="sm-type-badge">' +
                    groups.strs.length + '</span></div>';
            groups.strs.forEach(function(s) {
                let val = '';
                try { val = s.acc.value || ''; } catch (e) {}
                html += '<div class="icard"><label class="icard-label">' + RiveUtils.escapeAttr(s.name) +
                        '</label><input type="text" class="sinput" data-vm-str="' +
                        RiveUtils.escapeAttr(s.name) + '" value="' + RiveUtils.escapeAttr(val) + '"></div>';
            });
            html += '</div>';
        }

        // Render colors
        if (groups.colors.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">颜色 <span class="sm-type-badge">' +
                    groups.colors.length + '</span></div>';
            groups.colors.forEach(function(c) {
                let val = 0xFF000000;
                try { val = c.acc.value; } catch (e) {}
                const hex = RiveUtils.riveColorToHex(val);
                html += '<div class="icard"><label class="icard-label">' + RiveUtils.escapeAttr(c.name) + '</label>' +
                        '<div class="color-row">' +
                        '<div class="color-swatch" style="background:' + hex + '" data-vm-cswatch="' +
                        RiveUtils.escapeAttr(c.name) + '">' +
                        '<input type="color" data-vm-color="' + RiveUtils.escapeAttr(c.name) + '" value="' + hex + '">' +
                        '</div>' +
                        '<span class="color-hex" data-vm-chex="' + RiveUtils.escapeAttr(c.name) + '">' +
                        hex.toUpperCase() + '</span>' +
                        '</div></div>';
            });
            html += '</div>';
        }

        // Render enums
        if (groups.enums.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">枚举 <span class="sm-type-badge">' +
                    groups.enums.length + '</span></div>';
            groups.enums.forEach(function(en) {
                let val = '';
                let options = [];
                try { val = en.acc.value || ''; } catch (e) {}
                try { options = en.acc.values || []; } catch (e) {}
                html += '<div class="icard"><label class="icard-label">' + RiveUtils.escapeAttr(en.name) + '</label>';
                if (options.length) {
                    html += '<select class="sel" data-vm-enum="' + RiveUtils.escapeAttr(en.name) + '">';
                    options.forEach(function(opt) {
                        html += '<option value="' + RiveUtils.escapeAttr(opt) + '"' +
                                (opt === val ? ' selected' : '') + '>' + RiveUtils.escapeAttr(opt) + '</option>';
                    });
                    html += '</select>';
                } else {
                    html += '<input type="text" class="sinput" data-vm-enum="' +
                            RiveUtils.escapeAttr(en.name) + '" value="' + RiveUtils.escapeAttr(val) + '">';
                }
                html += '</div>';
            });
            html += '</div>';
        }

        // Render lists
        if (groups.lists.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">列表 <span class="sm-type-badge">' +
                    groups.lists.length + '</span></div>';
            groups.lists.forEach(function(l) {
                let size = 0;
                try { size = l.acc.size || 0; } catch (e) {}
                html += '<div class="icard"><span class="icard-label">' + RiveUtils.escapeAttr(l.name) +
                        '</span><span class="info-value" style="font-size:13px">' + size + ' 项</span></div>';
            });
            html += '</div>';
        }

        // Render nested ViewModels
        if (groups.viewModels.length) {
            html += '<div class="sm-type-group"><div class="sm-type-hd">嵌套视图模型 <span class="sm-type-badge">' +
                    groups.viewModels.length + '</span></div>';
            groups.viewModels.forEach(function(vm) {
                let childCount = 0;
                try { childCount = vm.acc.properties ? vm.acc.properties.length : 0; } catch (e) {}
                html += '<div class="icard"><span class="icard-label">' + RiveUtils.escapeAttr(vm.name) +
                        '</span><span class="info-value" style="font-size:13px">' + childCount + ' 个属性</span>';
                html += '<div class="vm-nested" data-vm-nested="' + RiveUtils.escapeAttr(vm.name) + '"></div>';
                html += '</div>';
            });
            html += '</div>';
        }

        if (!html) {
            container.innerHTML += '<div class="empty">暂无支持的属性</div>';
            return;
        }

        container.innerHTML = html;
        bindVMEvents(vmi, container);

        // Recursively render nested ViewModels (max 3 levels)
        if (depth < 3) {
            groups.viewModels.forEach(function(vm) {
                const nestedContainer = container.querySelector('[data-vm-nested="' + vm.name + '"]');
                if (nestedContainer && vm.acc) {
                    renderVMProperties(vm.acc, vm.name, nestedContainer, depth + 1);
                }
            });
        }
    }

    /**
     * Bind ViewModel property control events
     */
    function bindVMEvents(vmi, box) {
        // Triggers
        box.querySelectorAll('[data-vm-trg]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                try {
                    const t = vmi.trigger(btn.dataset.vmTrg);
                    if (t) {
                        t.trigger ? t.trigger() : (t.fire ? t.fire() : null);
                    }
                } catch (e) { console.warn('[Rive] VM trigger error:', btn.dataset.vmTrg, e); }
            });
        });

        // Booleans
        box.querySelectorAll('[data-vm-bool]').forEach(function(el) {
            el.addEventListener('change', function() {
                try {
                    const b = vmi.boolean(el.dataset.vmBool);
                    if (b) b.value = el.checked;
                } catch (e) { console.warn('[Rive] VM boolean error:', el.dataset.vmBool, e); }
            });
        });

        // Numbers
        box.querySelectorAll('[data-vm-num]').forEach(function(el) {
            el.addEventListener('input', function() {
                try {
                    const n = vmi.number(el.dataset.vmNum);
                    if (n) n.value = parseFloat(el.value) || 0;
                } catch (e) { console.warn('[Rive] VM number error:', el.dataset.vmNum, e); }
            });
        });

        // Strings
        box.querySelectorAll('[data-vm-str]').forEach(function(el) {
            el.addEventListener('input', function() {
                try {
                    const s = vmi.string(el.dataset.vmStr);
                    if (s) s.value = el.value;
                } catch (e) { console.warn('[Rive] VM string error:', el.dataset.vmStr, e); }
            });
        });

        // Colors
        box.querySelectorAll('[data-vm-color]').forEach(function(el) {
            el.addEventListener('input', function() {
                const name = el.dataset.vmColor;
                try {
                    const c = vmi.color(name);
                    if (c) c.value = RiveUtils.hexToRiveColor(el.value);
                } catch (e) { console.warn('[Rive] VM color error:', name, e); }
                const swatch = box.querySelector('[data-vm-cswatch="' + name + '"]');
                if (swatch) swatch.style.background = el.value;
                const hexLabel = box.querySelector('[data-vm-chex="' + name + '"]');
                if (hexLabel) hexLabel.textContent = el.value.toUpperCase();
            });
        });

        // Enums (support both select and input elements)
        box.querySelectorAll('[data-vm-enum]').forEach(function(el) {
            const evtName = el.tagName === 'SELECT' ? 'change' : 'input';
            el.addEventListener(evtName, function() {
                try {
                    const en = vmi.enum(el.dataset.vmEnum);
                    if (en) en.value = el.value;
                } catch (e) { console.warn('[Rive] VM enum error:', el.dataset.vmEnum, e); }
            });
        });
    }

    return {
        populateViewModel,
        loadVMProperties,
        renderVMProperties,
        bindVMEvents,
        getCurrentVMI: () => currentVMI
    };
})();

// Expose to global window object
window.DataBinding = DataBinding;


// ===== playback.js =====

/**
 * Playback control module for Rive
 * Handles speed and direction controls
 */

const Playback = (function() {
    let playbackSpeed = 1.0;
    let playDirection = 1; // 1: forward, -1: backward
    const minSpeed = 0.1;
    const maxSpeed = 3.0;

    /**
     * Set playback speed
     */
    function setSpeed(speed) {
        playbackSpeed = Math.max(minSpeed, Math.min(maxSpeed, speed));
        applyTimeScale();
        updateSpeedDisplay();
    }

    /**
     * Get current playback speed
     */
    function getSpeed() {
        return playbackSpeed;
    }

    /**
     * Update speed display UI
     */
    function updateSpeedDisplay() {
        const display = document.getElementById('speedDisplay');
        const slider = document.getElementById('speedSlider');

        if (display) {
            const percentage = Math.round(playbackSpeed * 100);
            display.textContent = percentage + '%';
        }

        if (slider) {
            slider.value = playbackSpeed;
        }
    }

    /**
     * Toggle playback direction
     */
    function toggleDirection() {
        playDirection *= -1;
        applyTimeScale();
        updateDirectionButton();
    }

    /**
     * Get current playback direction
     */
    function getDirection() {
        return playDirection;
    }

    /**
     * Update direction button appearance
     */
    function updateDirectionButton() {
        const btn = document.getElementById('directionBtn');
        if (!btn) return;

        if (playDirection === -1) {
            btn.classList.add('active');
            btn.title = '方向: 反向 (点击切换)';
        } else {
            btn.classList.remove('active');
            btn.title = '方向: 正向 (点击切换)';
        }
    }

    /**
     * Apply time scale to Rive instance
     */
    function applyTimeScale() {
        if (window.riveInstance) {
            const timeScale = playbackSpeed * playDirection;
            window.riveInstance.timeScale = timeScale;
        }
    }

    return {
        // Speed control
        setSpeed,
        getSpeed,
        updateSpeedDisplay,
        // Direction control
        toggleDirection,
        getDirection,
        updateDirectionButton,
        applyTimeScale
    };
})();

// Expose to global window object
window.Playback = Playback;


// ===== playback-controls.js =====

/**
 * Playback controls UI module
 * Initializes speed slider and direction button
 */

(function() {
    'use strict';

    /**
     * Initialize speed control slider
     */
    function initSpeedControl() {
        const controlsBar = document.querySelector('.controls-bar');
        if (!controlsBar) {
            console.warn('[PlaybackControls] Controls bar not found');
            return;
        }

        // Create speed control container
        const speedControl = document.createElement('div');
        speedControl.className = 'speed-control';
        speedControl.innerHTML = `
            <label for="speedSlider">速度</label>
            <input type="range"
                   id="speedSlider"
                   min="0.1"
                   max="3.0"
                   step="0.1"
                   value="1.0">
            <span id="speedDisplay">100%</span>
        `;

        const slider = speedControl.querySelector('#speedSlider');
        slider.addEventListener('input', (e) => {
            if (window.Playback) {
                const speed = parseFloat(e.target.value);
                window.Playback.setSpeed(speed);
            }
        });

        // Insert before background swatches
        const bgSwatches = controlsBar.querySelector('.bg-swatches');
        if (bgSwatches) {
            controlsBar.insertBefore(speedControl, bgSwatches);
        } else {
            controlsBar.appendChild(speedControl);
        }

        // Initialize display
        if (window.Playback) {
            window.Playback.updateSpeedDisplay();
        }
    }

    /**
     * Initialize direction toggle button
     */
    function initDirectionButton() {
        const controlsBar = document.querySelector('.controls-bar');
        if (!controlsBar) {
            console.warn('[PlaybackControls] Controls bar not found');
            return;
        }

        // Create direction button
        const directionBtn = document.createElement('button');
        directionBtn.id = 'directionBtn';
        directionBtn.className = 'direction-btn';
        directionBtn.title = '方向: 正向 (点击切换)';
        directionBtn.innerHTML = `
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        `;

        directionBtn.addEventListener('click', () => {
            if (window.Playback) {
                window.Playback.toggleDirection();
            }
        });

        // Insert after zoom controls
        const zoomControls = controlsBar.querySelector('.zoom-controls');
        if (zoomControls && zoomControls.nextSibling) {
            controlsBar.insertBefore(directionBtn, zoomControls.nextSibling);
        } else {
            controlsBar.appendChild(directionBtn);
        }

        // Initialize button state
        if (window.Playback) {
            window.Playback.updateDirectionButton();
        }
    }

    /**
     * Initialize all playback controls
     */
    function initPlaybackControls() {
        initSpeedControl();
    }

    // Expose public API
    window.PlaybackControls = {
        init: initPlaybackControls,
        initSpeedControl
    };
})();


// ===== zoom.js =====

/**
 * Zoom control module for Rive viewer
 */

const Zoom = (function() {
    let scale = 1;
    const minScale = 0.1;
    const maxScale = 10;

    // Pan state
    let isPanning = false;
    let panStartX = 0;
    let panStartY = 0;
    let translateX = 0;
    let translateY = 0;
    let hasPanned = false; // Track if user actually dragged while space was pressed

    /**
     * Set zoom level with optional mouse position
     */
    function setZoom(newScale, mouseX, mouseY) {
        const oldScale = scale;
        scale = Math.max(minScale, Math.min(maxScale, newScale));

        // Calculate zoom center (mouse position if provided, otherwise center of canvas)
        const canvas = document.getElementById('riveCanvas');
        if (canvas && mouseX !== undefined && mouseY !== undefined) {
            const rect = canvas.getBoundingClientRect();
            const canvasCenterX = rect.width / 2;
            const canvasCenterY = rect.height / 2;

            // Calculate mouse position relative to canvas center
            const mouseRelativeX = mouseX - rect.left - canvasCenterX;
            const mouseRelativeY = mouseY - rect.top - canvasCenterY;

            // Adjust translate to keep mouse position fixed during zoom
            translateX += (mouseRelativeX * (oldScale - scale)) / oldScale;
            translateY += (mouseRelativeY * (oldScale - scale)) / oldScale;
        } else {
            // Reset to center when no mouse position provided
            if (newScale === 1) {
                translateX = 0;
                translateY = 0;
            }
        }

        updateCanvasTransform();
        updateZoomDisplay();
    }

    /**
     * Update canvas CSS transform with scale and translation
     */
    function updateCanvasTransform() {
        const canvas = document.getElementById('riveCanvas');
        if (canvas) {
            canvas.style.transform = `translate(${translateX}px, ${translateY}px) scale(${scale})`;
            canvas.style.transformOrigin = 'center center';
        }
    }

    /**
     * Update zoom display text
     */
    function updateZoomDisplay() {
        const display = document.getElementById('zoomDisplay');
        if (display) {
            display.textContent = Math.round(scale * 100) + '%';
        }
    }

    /**
     * Zoom in (center of canvas)
     */
    function zoomIn() {
        setZoom(scale * 1.2);
    }

    /**
     * Zoom out (center of canvas)
     */
    function zoomOut() {
        setZoom(scale / 1.2);
    }

    /**
     * Reset zoom to 100% and reset pan
     */
    function resetZoom() {
        setZoom(1);
        translateX = 0;
        translateY = 0;
        updateCanvasTransform();
    }

    /**
     * Fit to container
     */
    function fitToContainer() {
        resetZoom();
    }

    /**
     * Handle mouse wheel zoom with mouse position
     */
    function handleWheel(event) {
        if (event.ctrlKey || event.metaKey) {
            event.preventDefault();
            const delta = event.deltaY > 0 ? 0.9 : 1.1;
            setZoom(scale * delta, event.clientX, event.clientY);
        } else if (isPanning) {
            // Regular wheel: pan if space is pressed
            event.preventDefault();
            translateX -= event.deltaX;
            translateY -= event.deltaY;
            updateCanvasTransform();
        }
    }

    /**
     * Start panning (on space key down)
     */
    function startPan() {
        isPanning = true;
        hasPanned = false;
        const canvas = document.getElementById('canvasContainer');
        if (canvas) {
            canvas.style.cursor = 'grab';
        }
    }

    /**
     * Stop panning (on space key up)
     */
    function stopPan() {
        isPanning = false;
        const canvas = document.getElementById('canvasContainer');
        if (canvas) {
            canvas.style.cursor = 'default';
        }
    }

    /**
     * Handle pan drag
     */
    function handlePanStart(event) {
        if (isPanning) {
            event.preventDefault();
            panStartX = event.clientX - translateX;
            panStartY = event.clientY - translateY;
            const canvas = document.getElementById('canvasContainer');
            if (canvas) {
                canvas.style.cursor = 'grabbing';
            }
        }
    }

    function handlePanMove(event) {
        if (isPanning && event.buttons === 1) {
            event.preventDefault();
            hasPanned = true;
            translateX = event.clientX - panStartX;
            translateY = event.clientY - panStartY;
            updateCanvasTransform();
        }
    }

    function handlePanEnd() {
        if (isPanning) {
            const canvas = document.getElementById('canvasContainer');
            if (canvas) {
                canvas.style.cursor = 'grab';
            }
        }
    }

    /**
     * Initialize zoom controls
     */
    function initControls() {
        const canvasContainer = document.getElementById('canvasContainer');

        if (canvasContainer) {
            // Mouse wheel zoom with Ctrl/Cmd key
            canvasContainer.addEventListener('wheel', handleWheel, { passive: false });

            // Pan events
            canvasContainer.addEventListener('mousedown', handlePanStart);
            document.addEventListener('mousemove', handlePanMove);
            document.addEventListener('mouseup', handlePanEnd);
        }

        // Zoom in button
        const zoomInBtn = document.getElementById('zoomInBtn');
        if (zoomInBtn) {
            zoomInBtn.addEventListener('click', zoomIn);
        }

        // Zoom out button
        const zoomOutBtn = document.getElementById('zoomOutBtn');
        if (zoomOutBtn) {
            zoomOutBtn.addEventListener('click', zoomOut);
        }

        // Reset zoom button
        const zoomResetBtn = document.getElementById('zoomResetBtn');
        if (zoomResetBtn) {
            zoomResetBtn.addEventListener('click', resetZoom);
        }

        // Keyboard shortcuts for pan
        document.addEventListener('keydown', function(e) {
            if (e.code === 'Space' && !e.repeat) {
                // Check if not typing in input field
                if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'SELECT' && e.target.tagName !== 'TEXTAREA') {
                    e.preventDefault();
                    startPan();
                }
            }
        });

        document.addEventListener('keyup', function(e) {
            if (e.code === 'Space') {
                stopPan();
            }
        });
    }

    return {
        setZoom,
        zoomIn,
        zoomOut,
        resetZoom,
        fitToContainer,
        initControls,
        getScale: () => scale
    };
})();

// Expose to global window object
window.Zoom = Zoom;


// ===== ui.js =====

/**
 * UI module for Rive viewer
 */

const UI = (function() {
    /**
     * Setup tab switching
     */
    function setupTabs(riveInstance) {
        document.querySelectorAll('.sidebar-tab').forEach(function(tab) {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.sidebar-tab').forEach(function(t) { t.classList.remove('active'); });
                document.querySelectorAll('.panel').forEach(function(p) { p.classList.remove('active'); });

                tab.classList.add('active');
                document.getElementById('panel-' + tab.dataset.tab).classList.add('active');

                const curSM = window.stateMachineModule ? window.stateMachineModule.getCurrentSM() : null;
                const curAnim = window.animationModule ? window.animationModule.getCurrentAnim() : null;

                // Tab switching logic
                if (tab.dataset.tab === 'timeline') {
                    // Switch to animation mode - stop state machine
                    if (curSM && window.riveInstance) {
                        window.riveInstance.stop(curSM);
                    }
                    // Play animation if exists, or play first animation
                    if (curAnim && window.riveInstance) {
                        if (window.animationModule) {
                            window.animationModule.playAnim(riveInstance, curAnim);
                        }
                    } else if (window.riveInstance) {
                        var anims = window.riveInstance.animationNames || [];
                        if (anims.length > 0) {
                            if (window.animationModule) {
                                window.animationModule.setCurrentAnim(anims[0]);
                                window.animationModule.playAnim(riveInstance, anims[0]);
                            }
                        }
                    }
                } else if (tab.dataset.tab === 'statemachine') {
                    // Switch to state machine mode - stop animation
                    if (curAnim && window.riveInstance) {
                        window.riveInstance.stop(curAnim);
                    }
                    // Play state machine if exists
                    if (curSM && window.riveInstance) {
                        if (window.stateMachineModule) {
                            window.stateMachineModule.playSM(riveInstance, curSM);
                        }
                    }
                }
            });
        });
    }

    /**
     * Setup background swatches
     */
    function setupBackgroundSwatches() {
        const container = document.getElementById('canvasContainer');

        document.querySelectorAll('.bg-swatch').forEach(function(swatch) {
            swatch.addEventListener('click', function() {
                document.querySelectorAll('.bg-swatch').forEach(function(s) { s.classList.remove('active'); });
                swatch.classList.add('active');

                container.className = 'canvas-container';
                const bg = swatch.dataset.bg;

                if (bg === 'checker') {
                    container.classList.add('bg-checker');
                } else if (bg === 'white') {
                    container.classList.add('bg-white');
                } else if (bg === 'black') {
                    container.classList.add('bg-black');
                }
            });
        });
    }

    /**
     * Setup artboard switching
     */
    function setupArtboardSwitch(riveInstance) {
        const abs = riveInstance.artboardNames || [];

        if (abs.length > 1) {
            document.getElementById('artboardRow').style.display = '';
            const sel = document.getElementById('artboardSelect');

            sel.innerHTML = abs.map(a => '<option value="' + a + '">' + a + '</option>').join('');

            sel.addEventListener('change', function() {
                switchArtboard(riveInstance, sel.value);
            });
        }
    }

    /**
     * Switch artboard
     */
    function switchArtboard(riveInstance, name) {
        const filePath = window.currentFilePath;

        if (riveInstance) riveInstance.cleanup();

        // Reset current SM and anim
        if (window.stateMachineModule) {
            window.stateMachineModule.setCurrentSM(null);
        }
        if (window.animationModule) {
            window.animationModule.setCurrentAnim(null);
        }

        const defaultLayout = new rive.Layout({
            fit: rive.Fit.Contain,
            alignment: rive.Alignment.Center
        });

        riveInstance = new rive.Rive({
            src: filePath,
            canvas: document.getElementById('riveCanvas'),
            artboard: name,
            autoplay: false,
            autoBind: true,
            layout: defaultLayout,
            onLoad: () => {
                riveInstance.resizeDrawingSurfaceToCanvas();

                try {
                    if (window.animationModule) {
                        window.animationModule.populateAnimations(riveInstance);
                    }
                } catch (e) { console.error('[Rive] switchArtboard populateAnimations error:', e); }

                try {
                    if (window.stateMachineModule) {
                        window.stateMachineModule.populateStateMachines(riveInstance);
                    }
                } catch (e) { console.error('[Rive] switchArtboard populateStateMachines error:', e); }

                try {
                    if (window.dataBindingModule) {
                        window.dataBindingModule.populateViewModel(riveInstance);
                    }
                } catch (e) { console.error('[Rive] switchArtboard populateViewModel error:', e); }

                // Start playback if no SM or anim
                const curSM = window.stateMachineModule ? window.stateMachineModule.getCurrentSM() : null;
                const curAnim = window.animationModule ? window.animationModule.getCurrentAnim() : null;

                if (!curSM && !curAnim) {
                    riveInstance.play();
                }
            },
        });

        if (window.playbackModule) {
            window.playbackModule.setPlaying(true);
        }

        // Update global instance reference
        window.riveInstance = riveInstance;
    }

    /**
     * Populate file info
     */
    function populateFileInfo(riveInstance) {
        const fileName = window.currentFilePath.split('/').pop().split('\\').pop();
        document.getElementById('fileName').textContent = fileName;

        const b = riveInstance.bounds;
        const w = b ? Math.round(b.maxX - b.minX) : 0;
        const h = b ? Math.round(b.maxY - b.minY) : 0;

        const anims = riveInstance.animationNames || [];
        const sms = riveInstance.stateMachineNames || [];
        let vmCount = 0;

        try { vmCount = riveInstance.viewModelCount || 0; } catch (e) {}

        document.getElementById('infoDims').textContent = w && h ? w + ' × ' + h : '-';
        document.getElementById('infoAnimCount').textContent = anims.length || '-';
        document.getElementById('infoSMCount').textContent = sms.length || '-';
        document.getElementById('infoVMCount').textContent = vmCount || '-';
    }

    /**
     * Show error message
     */
    function showError(msg) {
        const overlay = document.getElementById('overlay');
        overlay.innerHTML = '<div class="error-msg">' + msg + '</div>';
    }

    /**
     * Show .rev file notice
     */
    function showRevNotice() {
        const fileName = window.currentFilePath.split('/').pop().split('\\').pop();
        document.getElementById('fileName').textContent = fileName;

        // Hide timeline tab
        const timelineTab = document.querySelector('.sidebar-tab[data-tab="timeline"]');
        if (timelineTab) timelineTab.style.display = 'none';

        const overlay = document.getElementById('overlay');
        overlay.innerHTML =
            '<div class="rev-notice">' +
                '<span class="rev-badge">.REV 文件</span>' +
                '<div class="rev-title">Rive 编辑器备份文件</div>' +
                '<div class="rev-desc">' +
                    '这是 Rive 编辑器备份文件（.rev），包含完整的编辑项目数据。' +
                    'Rive 运行时无法预览此文件。<br><br>' +
                    '如需预览动画，请在 Rive 编辑器中打开并导出 .riv（运行时）文件。' +
                '</div>' +
                '<a class="rev-link" href="https://editor.rive.app/" target="_blank">打开 Rive 编辑器</a>' +
            '</div>';
    }

    return {
        setupTabs,
        setupBackgroundSwatches,
        setupArtboardSwitch,
        populateFileInfo,
        showError,
        showRevNotice
    };
})();

// Expose to global window object
window.UI = UI;


// ===== performance.js =====

/**
 * Performance monitoring module
 */

(function() {
    'use strict';

    // State
    let fps = 0;
    let frameCount = 0;
    let lastTime = performance.now();
    let animationFrameId = null;
    let updateInterval = 500; // Update every 500ms

    /**
     * Update FPS calculation
     */
    function updateFPS() {
        frameCount++;
        const currentTime = performance.now();
        const elapsed = currentTime - lastTime;

        if (elapsed >= updateInterval) {
            fps = Math.round((frameCount * 1000) / elapsed);
            frameCount = 0;
            lastTime = currentTime;

            updateDisplay();
        }

        animationFrameId = requestAnimationFrame(updateFPS);
    }

    /**
     * Update FPS display
     */
    function updateDisplay() {
        const display = document.getElementById('fpsDisplay');
        if (display) {
            display.textContent = fps + ' FPS';

            // Update color class
            display.className = 'fps-indicator ' + getFPSClass(fps);
        }
    }

    /**
     * Get CSS class based on FPS value
     */
    function getFPSClass(fpsValue) {
        if (fpsValue >= 55) return 'fps-good';
        if (fpsValue >= 30) return 'fps-ok';
        return 'fps-poor';
    }

    /**
     * Start FPS monitoring
     */
    function start() {
        if (animationFrameId === null) {
            lastTime = performance.now();
            frameCount = 0;
            animationFrameId = requestAnimationFrame(updateFPS);
        }
    }

    /**
     * Stop FPS monitoring
     */
    function stop() {
        if (animationFrameId !== null) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
    }

    /**
     * Initialize FPS monitor
     */
    function initFPSMonitor() {
        try {
            // Find canvas area container
            const canvasArea = document.querySelector('.canvas-area');
            if (!canvasArea) {
                console.warn('[Performance] Canvas area not found');
                return;
            }

            // Check if FPS display already exists
            let fpsDisplay = document.getElementById('fpsDisplay');
            if (!fpsDisplay) {
                fpsDisplay = document.createElement('div');
                fpsDisplay.id = 'fpsDisplay';
                fpsDisplay.className = 'fps-indicator fps-good';
                fpsDisplay.textContent = '-- FPS';
                fpsDisplay.title = '帧率显示';
                canvasArea.appendChild(fpsDisplay);
            }

            // Start monitoring after a short delay to ensure DOM is ready
            setTimeout(() => {
                start();
            }, 100);
        } catch (e) {
            console.error('[Performance] Initialization error:', e);
        }
    }

    /**
     * Get current FPS value
     */
    function getFPS() {
        return fps;
    }

    /**
     * Set update interval
     */
    function setUpdateInterval(interval) {
        updateInterval = Math.max(100, interval); // Minimum 100ms
    }

    // Expose public API
    window.Performance = {
        init: initFPSMonitor,
        start,
        stop,
        getFPS,
        setUpdateInterval
    };
})();


// ===== shortcuts.js =====

/**
 * Shortcuts help panel module
 */

(function() {
    'use strict';

    // Shortcuts configuration
    const SHORTCUTS = [
        { key: 'Ctrl+0', desc: '重置缩放' },
        { key: 'Ctrl++', desc: '放大' },
        { key: 'Ctrl+-', desc: '缩小' },
        { key: '按住 Space + 拖动', desc: '平移画布' },
        { key: 'Ctrl + 滚轮', desc: '缩放' }
    ];

    let panel = null;

    /**
     * Create shortcuts panel element
     */
    function createPanel() {
        const div = document.createElement('div');
        div.className = 'shortcuts-panel';
        div.innerHTML = `
            <div class="shortcuts-overlay" id="shortcutsOverlay"></div>
            <div class="shortcuts-content">
                <div class="shortcuts-header">
                    <h3>快捷键</h3>
                    <button class="shortcuts-close" id="shortcutsClose" title="关闭">×</button>
                </div>
                <ul class="shortcuts-list">
                    ${SHORTCUTS.map(s => `
                        <li>
                            <kbd>${s.key}</kbd>
                            <span>${s.desc}</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;

        // Setup close handlers
        const overlay = div.querySelector('#shortcutsOverlay');
        const closeBtn = div.querySelector('#shortcutsClose');

        const close = () => hidePanel();
        overlay.addEventListener('click', close);
        closeBtn.addEventListener('click', close);

        // Close on Escape key
        const escapeHandler = (e) => {
            if (e.key === 'Escape') {
                close();
                document.removeEventListener('keydown', escapeHandler);
            }
        };
        document.addEventListener('keydown', escapeHandler);

        return div;
    }

    /**
     * Show shortcuts panel
     */
    function showPanel() {
        if (!panel) {
            panel = createPanel();
        }

        document.body.appendChild(panel);
        // Trigger reflow for animation
        panel.offsetHeight;
        panel.classList.add('visible');
    }

    /**
     * Hide shortcuts panel
     */
    function hidePanel() {
        if (panel) {
            panel.classList.remove('visible');
            setTimeout(() => {
                if (panel && panel.parentNode) {
                    panel.parentNode.removeChild(panel);
                }
            }, 300);
        }
    }

    /**
     * Toggle shortcuts panel visibility
     */
    function togglePanel() {
        if (panel && panel.parentNode) {
            hidePanel();
        } else {
            showPanel();
        }
    }

    /**
     * Initialize shortcuts help button
     */
    function initShortcutsButton() {
        // Find the right side controls container
        const controlsRight = document.querySelector('.controls-right');
        if (!controlsRight) {
            console.warn('[Shortcuts] Controls right container not found');
            return;
        }

        // Create help button
        const btn = document.createElement('button');
        btn.className = 'help-btn';
        btn.id = 'shortcutsHelpBtn';
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-18a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm1 13h-2v-2h2v2zm0-4h-2V7h2v4z"/></svg>';
        btn.title = '快捷键帮助';
        btn.onclick = togglePanel;

        // Add to right side controls
        controlsRight.appendChild(btn);
    }

    // Expose public API
    window.Shortcuts = {
        show: showPanel,
        hide: hidePanel,
        toggle: togglePanel,
        init: initShortcutsButton
    };
})();


// ===== app.js =====

/**
 * Main application entry point for Rive viewer
 */

(function() {
    'use strict';

    // ===== Params =====
    const params = new URLSearchParams(location.search);
    const filePath = params.get('path');
    const theme = params.get('theme') || 'light';

    // Store for global access
    window.currentFilePath = filePath;
    window.riveInstance = null;

    // Setup module references early (before any module code runs)
    window.stateMachineModule = window.StateMachine || null;
    window.animationModule = window.Animation || null;
    window.dataBindingModule = window.DataBinding || null;
    window.playbackModule = window.Playback || null;
    window.zoomModule = window.Zoom || null;

    // Apply theme
    if (theme === 'dark') {
        document.body.classList.add('dark-theme');
    }

    // ===== Refs =====
    const canvas = document.getElementById('riveCanvas');
    const overlay = document.getElementById('overlay');
    const container = document.getElementById('canvasContainer');

    // ===== Default Layout =====
    const defaultLayout = new rive.Layout({
        fit: rive.Fit.Contain,
        alignment: rive.Alignment.Center
    });

    // ===== Canvas sizing =====
    function fitCanvas() {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        if (window.riveInstance) {
            window.riveInstance.resizeDrawingSurfaceToCanvas();
        }
    }

    // ===== Initialize Rive =====
    function initRive() {
        if (!filePath) {
            if (window.UI) {
                window.UI.showError('未指定文件路径');
            }
            return;
        }

        // Check for .rev file (editor backup, runtime cannot load)
        const ext = filePath.split('.').pop().toLowerCase();
        if (ext === 'rev') {
            if (window.UI) {
                window.UI.showRevNotice();
            }
            return;
        }

        fitCanvas();

        window.riveInstance = new rive.Rive({
            src: filePath,
            canvas: canvas,
            autoplay: false,
            autoBind: true,
            layout: defaultLayout,
            onLoad: () => {
                overlay.classList.add('hidden');
                window.riveInstance.resizeDrawingSurfaceToCanvas();
                populateUI();

                // Start playback if no SM or anim
                const curSM = window.stateMachineModule ? window.stateMachineModule.getCurrentSM() : null;
                const curAnim = window.animationModule ? window.animationModule.getCurrentAnim() : null;

                if (!curSM && !curAnim) {
                    window.riveInstance.play();
                }
            },
            onLoadError: () => {
                if (window.UI) {
                    window.UI.showError('Rive 文件加载失败');
                }
            },
        });
    }

    /**
     * Populate all UI elements
     */
    function populateUI() {
        if (!window.riveInstance) return;

        // Setup UI components
        if (window.UI) {
            window.UI.setupTabs(window.riveInstance);
            window.UI.setupBackgroundSwatches();
            window.UI.populateFileInfo(window.riveInstance);
            window.UI.setupArtboardSwitch(window.riveInstance);
        }

        // Populate animations
        try {
            if (window.Animation) {
                window.Animation.populateAnimations(window.riveInstance);
            }
        } catch (e) {
            console.error('[Rive] populateAnimations error:', e);
        }

        // Populate state machines
        try {
            if (window.StateMachine) {
                window.StateMachine.populateStateMachines(window.riveInstance);
            }
        } catch (e) {
            console.error('[Rive] populateStateMachines error:', e);
        }

        // Populate ViewModel
        try {
            if (window.DataBinding) {
                window.DataBinding.populateViewModel(window.riveInstance);
            }
        } catch (e) {
            console.error('[Rive] populateViewModel error:', e);
        }

        // Apply initial time scale for playback speed
        if (window.Playback) {
            window.Playback.applyTimeScale();
        }
    }

    // ===== Resize handler =====
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(fitCanvas, 80);
    });

    // ===== Keyboard shortcuts =====
    document.addEventListener('keydown', function(e) {
        // Zoom shortcuts (Ctrl/Cmd + +, -, 0)
        if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey) {
            if (e.key === '=' || e.key === '+') {
                e.preventDefault();
                if (window.Zoom) window.Zoom.zoomIn();
            } else if (e.key === '-' || e.key === '_') {
                e.preventDefault();
                if (window.Zoom) window.Zoom.zoomOut();
            } else if (e.key === '0') {
                e.preventDefault();
                if (window.Zoom) window.Zoom.resetZoom();
            }
        }
    });

    // ===== Cleanup on unload =====
    window.addEventListener('beforeunload', () => {
        if (window.riveInstance) {
            window.riveInstance.cleanup();
        }
    });

    // ===== Initialize =====
    // Setup playback UI controls (speed & direction)
    try {
        if (window.PlaybackControls) {
            window.PlaybackControls.init();
        }
    } catch (e) {
        console.error('[App] PlaybackControls init error:', e);
    }

    // Setup zoom controls
    try {
        if (window.Zoom) {
            window.Zoom.initControls();
        }
    } catch (e) {
        console.error('[App] Zoom init error:', e);
    }

    // Setup performance monitoring
    try {
        if (window.Performance) {
            window.Performance.init();
        }
    } catch (e) {
        console.error('[App] Performance init error:', e);
    }

    // Setup shortcuts help
    try {
        if (window.Shortcuts) {
            window.Shortcuts.init();
        }
    } catch (e) {
        console.error('[App] Shortcuts init error:', e);
    }

    // Start
    initRive();

})();

